Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/angularjs-crud-operations-php-mysql/

============ Instruction ============
1. Create a database (for example, codexworld) and import the "users.sql" file into this database.
2. Open the "DB.php" file => change the $dbHost, $dbUsername, $dbPassword, and $dbName variable's value as per your phpMyAdmin details.
3. Browse the "index.index" file on the browser and test the AngularJS CRUD functionality. In this page, you can add, edit, update, and delete users data without refresh the page.


============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/angularjs-crud-operations-php-mysql/#respond